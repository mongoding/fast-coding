package com.ding.dao;

import org.durcframework.core.dao.BaseDao;
import com.ding.entity.BackUser;

public interface BackUserDao extends BaseDao<BackUser> {
}