package com.ding.controller;

import org.durcframework.core.GridResult;
import org.durcframework.core.MessageResult;
import org.durcframework.core.controller.CrudController;
import com.ding.entity.BackUser;
import com.ding.entity.BackUserSch;
import com.ding.service.BackUserService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class BackUserController extends
		CrudController<BackUser, BackUserService> {

	@RequestMapping("/addBackUser.do")
	public @ResponseBody
	MessageResult addBackUser(BackUser entity) {
		return this.save(entity);
	}

	@RequestMapping("/listBackUser.do")
	public @ResponseBody
	GridResult listBackUser(BackUserSch searchEntity) {
		return this.query(searchEntity);
	}

	@RequestMapping("/updateBackUser.do")
	public @ResponseBody
	MessageResult updateBackUser(BackUser entity) {
		return this.update(entity);
	}

	@RequestMapping("/delBackUser.do")
	public @ResponseBody
	MessageResult delBackUser(BackUser entity) {
		return this.delete(entity);
	}
	
}