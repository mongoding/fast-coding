package com.ding.service;

import org.durcframework.core.service.CrudService;
import com.ding.dao.BackUserDao;
import com.ding.entity.BackUser;
import org.springframework.stereotype.Service;

@Service
public class BackUserService extends CrudService<BackUser, BackUserDao> {

}